Main contributor: Conrad "Lynx" Wong (Kytten)

Contributor and Maintainer: Jorge C. Leitão (Pyglet-gui)
